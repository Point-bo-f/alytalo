﻿namespace TxtTaloAsetLamp
{
    internal class Text
    {
    }
}